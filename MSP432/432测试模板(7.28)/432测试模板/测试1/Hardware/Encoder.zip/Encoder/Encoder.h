#ifndef __ENCODER_H
#define __ENCODER_H

#include "sys.h"

extern volatile int Encoder_1_SUM;
extern volatile int Encoder_2_SUM;
extern volatile int Speed_1;
extern volatile int Speed_2;
extern volatile int Encoder_Flag;
extern volatile int Overflow[2];

#define getDrv_Encoder_A1()  (GPIO_getInputPinValue(GPIO_PORT_P2,GPIO_PIN7)) //D������ D�ź� ����� 
#define getDrv_Encoder_A2()  (GPIO_getInputPinValue(GPIO_PORT_P8,GPIO_PIN2))//D������ D�ź� ����� 

void Encoder1_Cap_Init(void);
void Encoder2_Cap_Init(void);
void Encoder_Cap_Init(void);
int cc(int a);
#endif
